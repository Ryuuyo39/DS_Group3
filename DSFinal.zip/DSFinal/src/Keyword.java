//lab6
public class Keyword {
	public String name;
	public String url;
	public double weight;
	
	public Keyword(String name, String url, double weight){
		this.name = name;
		this.url = url;
		this.weight = weight;
	}
	
	public void setWeight(double newWeight) {
		weight = newWeight;
	}
}
