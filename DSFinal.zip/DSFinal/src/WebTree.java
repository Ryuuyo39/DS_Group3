import java.io.IOException;
import java.util.ArrayList;
//lab6
public class WebTree {
	public WebNode root;
	

	
	public WebTree(HTMLHandler rootPage){
		this.root = new WebNode(rootPage);
	}
	
	public void setPostOrderScore(int w) throws IOException{
		setPostOrderScore(root, w);
	}
	
	private void setPostOrderScore(WebNode startNode, int w) throws IOException{
		//2. compute the score of children nodes via post-order, then setNodeScore for startNode
		for(WebNode child:startNode.children) {
			setPostOrderScore(child, w);
		}
		startNode.setNodeScore(w);
		
	}
	
	public void eularPrintTree(){
		eularPrintTree(root);
	}
	
	private void eularPrintTree(WebNode startNode){
		int nodeDepth = startNode.getDepth();
		
		if(nodeDepth > 1) System.out.print("\n" + repeat("\t", nodeDepth-1));

		System.out.print("(");
		System.out.print(startNode.webPage.name + "," + startNode.nodeScore);
		
		//3. print child via pre-order
		for(WebNode child:startNode.children) {
			eularPrintTree(child);
		}
		
		System.out.print(")");
				
		if(startNode.isTheLastChild()) System.out.print("\n" + repeat("\t", nodeDepth-2));	
	}
	
	private String repeat(String str, int repeat){
		String retVal = "";
		for(int i = 0; i < repeat; i++){
			retVal += str;
		}
		return retVal;
	}
}