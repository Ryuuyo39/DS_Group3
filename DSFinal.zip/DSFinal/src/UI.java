import java.util.ArrayList;
import javax.swing.*;

public class UI 
{
	public JButton search;
	public JTextField userKeyword;
	public JTextArea results;
	
	public UI(){}
//	public ArrayList<String> getInstance(){}
	public void showResult() {}
	
}