//import java.util.ArrayList;
//
//public class RelativeKeyword
//{
//	public String rKeyword;
//	public int count;
//	public double weight;
//	
//	public RelativeKeyword(){
//		
//	}
//	public double score(){}
//	
//}