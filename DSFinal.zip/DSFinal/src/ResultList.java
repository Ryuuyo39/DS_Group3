import java.util.ArrayList;
import javax.print.DocFlavor.URL;

public class ResultList 
{
	public ArrayList<URL> urls;
	public ArrayList<String> titles;
	
	public ResultList() {}
	
}